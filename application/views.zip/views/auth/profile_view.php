
                <div class="prtm-content">
                    <div class="prtm-page-bar">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item text-capitalize">
                                <h3>Settings</h3> </li>
                            <li class="breadcrumb-item active"><a href="">Profile</a></li>
                        </ul>
                    </div>
                    <div class="data-table-style">
                        <div class="prtm-block pos-relative">
                            <div class="prtm-block-title mrgn-b-lg">
                                <div class="caption">
                                    <h3 class="text-capitalize">Admin Details</h3> 
                                </div>
                            </div>
                            <div class="prtm-block-content">
                                <div class="prtm-full-block text-center">
                                <div class="pad-all-md">
                                    <div class="pos-relative">
                                    </div>
                                    <div class="mrgn-b-lg"> <img class="img-responsive img-circle display-ib" src="<?php echo base_url(); ?>assets/img/user-5.jpg" width="140" height="140" alt="user profile image"> </div>
                                    <h5>Terrance arnold</h5>
                                    <p>Art director</p>
                                    <p>Hi! I'm Terrance arnold the Senior UI Designer at LTMR. We hope you enjoy the design and quality here.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>