<footer class="footer-wrapper">
                    <div class="prtm-footer clearfix">
                        <div class="row footer-area pad-lr-md">
                            <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                <p>Copyright 2017 | All Rights Reserved </p>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 text-right">
                                <a href=""><img src="" width="218" height="23" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <a href="#" id="back-top" class="to-top scrolled"> <span class="to-top-icon"></span> </a>
                </footer>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/vendor.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/pratham.min.js" type="text/javascript"></script>
</body>

</html>