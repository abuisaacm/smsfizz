
                <div class="prtm-content">
                    <div class="row prtm-card-wrapper">
                        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 half-col-lg-md">
                            <div class="prtm-card prtm-card-box graph bg-primary pad-all-md mrgn-b-lg">
                                <div class="prtm-card-info">
                                    <div class="mrgn-b-lg clearfix">
                                        <div class="pull-left"> <span class="show">WELCOME <?php echo $this->session->name; ?></span>You are logged in to SMSFIZZ! <span></span> </div>
                                        <!--div class="pull-right text-right"> <span class="font-counter"><span class="count-item" data-count="1300">0</span></span>
                                        </div-->
                                    </div>
                                    <!--div class="prtm-card-progress">
                                        <div class="progress progress-xs-height">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" data-width="85%"> <span class="sr-only"></span> </div>
                                        </div>
                                    </div-->
                                </div>
                            </div>
                            <!--prtm-card closed-->
                        </div>
                    </div>
                </div>